import 'package:flutter/material.dart';
import '../components/user_tile.dart';
import '../services/authentication/auth_services.dart';
import '../services/chat/chat_services.dart';
import 'chat_page.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});
  // chat and auth services

  final ChatServices _chatservice = ChatServices();
  final Authservice _authservice = Authservice();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(
            "My Chat App",
            style: TextStyle(
              fontSize: 30,
              color: Colors.grey.shade700,
              fontWeight: FontWeight.bold,
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                _authservice.signOut();
              },
              icon: Icon(Icons.logout),
            )
          ],
        ),
        // drawer: const MyDrawer(),
        body: _buildUserList(),
      ),
    );
  }

  // build a list of users except for the the current logged in user
  Widget _buildUserList() {
    return StreamBuilder(
        stream: _chatservice.getUsersStream(),
        builder: (context, snapshot) {
          // error
          if (snapshot.hasError) {
            return const Text("Error");
          }

          // loading..
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Loading...",
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ));
          }

          //return listview

          return ListView(
            children: snapshot.data!
                .map<Widget>(
                    (userData) => _buildUserListItem(userData, context))
                .toList(),
          );
        });
  }

  // build individual list tile for user

  Widget _buildUserListItem(
      Map<String, dynamic> userData, BuildContext context) {
    // display all user except the current user

    if (userData["email"] != _authservice.getCurrentUser()!.email) {
      return UserTile(
        text: userData["email"],
        onTap: () {
          // tapped on a user -> goto chat page
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatPage(
                receivedEmail: userData['email'],
                receiverID: userData['uid'],
              ),
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }
}

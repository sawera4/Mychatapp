package com.chatapp.chatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
